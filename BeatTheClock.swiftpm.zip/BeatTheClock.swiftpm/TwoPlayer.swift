//
//  GameView.swift
//  BeatTheClock
//
//  Created by Raffaele Marino  on 12/02/24.
//

import SwiftUI

struct TwoPlayer: View {
    
    var clock = ClockModel()
    
    var body: some View {
        NavigationStack {
            ZStack {
                Image("TwoPlayer")
                    .resizable()
                    .ignoresSafeArea()
                HStack {
                    GenerateClock()
                    NavigationLink(destination: {
                        HomePage()
                    }, label: {
                        Image("Home")
                            .resizable()
                            .frame(width: 70, height: 110)
                            .padding(.bottom)
                    }).frame(width: 100, height: 110)
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.red, lineWidth: 5)
                        )
                    GenerateClock()
                        .rotationEffect(.degrees(180))
                }
            }.navigationBarBackButtonHidden(true)
        }
    }
}
struct GenerateClock: View {
    
    var clock = ClockModel()
    
    @State private var isButtonClicked = false
    
    var body: some View {
        ForEach(clock.clocklist.shuffled().prefix(1))
        {clockList in
            HStack {
                VStack {
                    Image(clockList.image)
                        .resizable()
                        .frame(width: 550, height: 450)
                    HStack {
                        VStack {
                            ForEach(clock.clocklist.shuffled().prefix(1))
                            {clockList in
                                Button(action: {
                                    self.isButtonClicked.toggle()
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: {
                                        self.isButtonClicked = false
                                    })
                                }, label: {
                                    Text(clockList.code)
                                        .font(.system(size: 40))
                                        .foregroundColor(.red)
                                }).frame(width: 150, height: 100)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color.red, lineWidth: 5)
                                    )
                                    .background(isButtonClicked ? Color.green : Color(white: 1.0).opacity(0.8))
                                    .padding(.trailing)
                            }
                            
                            Button {
                                
                            } label: {
                                Text(clockList.code)
                                    .font(.system(size: 40))
                                    .foregroundColor(.red)
                            }
                            .frame(width: 150, height: 100)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.red, lineWidth: 5)
                            )
                            .background(Color(white: 1.0).opacity(0.8))
                            .padding(.trailing)
                        }
                        VStack {
                            ForEach(clock.clocklist.shuffled().prefix(1))
                            {clockList in
                                Button {
                                    
                                } label: {
                                    Text(clockList.code)
                                        .font(.system(size: 40))
                                        .foregroundColor(.red)
                                }.frame(width: 150, height: 100)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color.red, lineWidth: 5)
                                    )
                                    .background(Color(white: 1.0).opacity(0.8))
                                    .padding(.leading)
                            }
                            ForEach(clock.clocklist.shuffled().prefix(1))
                            {clockList in
                                Button {
                                    
                                } label: {
                                    Text(clockList.code)
                                        .font(.system(size: 40))
                                        .foregroundColor(.red)
                                }.frame(width: 150, height: 100)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color.red, lineWidth: 5)
                                    )
                                    .background(Color(white: 1.0).opacity(0.8))
                                    .padding(.leading)
                            }
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    TwoPlayer()
}
