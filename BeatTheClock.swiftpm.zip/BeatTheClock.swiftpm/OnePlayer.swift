//
//  1Player.swift
//  BeatTheClock
//
//  Created by Raffaele Marino  on 12/02/24.
//

import SwiftUI

struct OnePlayer: View {
    
    var clock = ClockModel()
    @State private var isButtonClicked = false
    @State private var isHomeButtonTapped = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                VStack {
                    Text("CAN YOU GUESS??")
                        .font(.system(size: 100))
                        .foregroundColor(.red)
                        .padding(.top)
                    Spacer()
                }.zIndex(1)
                Image("TwoPlayer")
                    .resizable()
                    .ignoresSafeArea()
                VStack {
                    Spacer()
                    .hidden()
                    NavigationLink(destination: {
                        HomePage()
                    }, label: {
                        Image("Home")
                            .resizable()
                            .frame(width: 70, height: 110)
                            .padding(.bottom)
                    }).frame(width: 100, height: 110)
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.red, lineWidth: 5)
                        )
                        .background(Color(white: 1.0).opacity(0.8))
                        .padding(.bottom)
                }
                HStack {
                    ForEach(clock.clocklist.shuffled().prefix(1))
                    {clockList in
                        Image(clockList.image)
                            .resizable()
                            .frame(width: 600, height: 500)
                        Spacer()
                        
                        VStack {
                            HStack {
                                Button {
                                    self.isButtonClicked = true
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute: {
                                        self.isButtonClicked = false
                                    })
                                } label: {
                                    Text(clockList.code)
                                        .font(.system(size: 70))
                                        .foregroundColor(.red)
                                        .frame(width: 200, height: 150)
                                }.frame(width: 200, height: 150)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color.red, lineWidth: 5)
                                    )
                                    .background(isButtonClicked ? Color.green : Color(white: 1.0).opacity(0.8))
                                    .padding(.trailing)
                                
                                ForEach(clock.clocklist.shuffled().prefix(1))
                                {clockList in
                                    Button {
                                        
                                    } label: {
                                        Text(clockList.code)
                                            .font(.system(size: 70))
                                            .foregroundColor(.red)
                                            .frame(width: 200, height: 150)
                                    }.frame(width: 200, height: 150)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 20)
                                                .stroke(Color.red, lineWidth: 5)
                                        )
                                        .background(Color(white: 1.0).opacity(0.8))
                                        .padding(.trailing)
                                }
                            }
                            HStack {
                                ForEach(clock.clocklist.shuffled().prefix(1))
                                {clockList in
                                    Button {
                                        
                                    } label: {
                                        Text(clockList.code)
                                            .font(.system(size: 70))
                                            .foregroundColor(.red)
                                            .frame(width: 200, height: 150)
                                    }.frame(width: 200, height: 150)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 20)
                                                .stroke(Color.red, lineWidth: 5)
                                        )
                                        .background(Color(white: 1.0).opacity(0.8))
                                        .padding(.trailing)
                                    ForEach(clock.clocklist.shuffled().prefix(1))
                                    {clockList in
                                        Button {
                                            
                                        } label: {
                                            Text(clockList.code)
                                                .font(.system(size: 70))
                                                .foregroundColor(.red)
                                                .frame(width: 200, height: 150)
                                        }.frame(width: 200, height: 150)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 20)
                                                    .stroke(Color.red, lineWidth: 5)
                                            )
                                            .background(Color(white: 1.0).opacity(0.8))
                                            .padding(.trailing)
                                    }
                                    
                                }
                                
                            }
                        }
                        
                        Spacer()
                    }
                    Spacer()
                }
            }.navigationBarBackButtonHidden(true)
        }
    }
}


#Preview {
    OnePlayer()
}
