//
//  ClockList.swift
//  BeatTheClock
//
//  Created by Raffaele Marino  on 13/02/24.
//

import Foundation

class ClockList: Identifiable {
    let id: UUID
    let image: String
    let sun: Bool
    let moon: Bool
    let code: String
    
    init(id: UUID = UUID(), image: String, sun: Bool, moon: Bool, code: String) {
        self.id = id
        self.image = image
        self.sun = sun
        self.moon = moon
        self.code = code
    }
}
