import SwiftUI

struct HomePage: View {
    var body: some View {
        NavigationStack{
            ZStack {
                Image("HomePage")
                    .resizable()
                    .ignoresSafeArea()
                    .zIndex(1)
                HStack(spacing: 280){
                    NavigationLink(destination: {
                        OnePlayer()
                    }, label: {
                        Text("1 Player")
                            .frame(width: 300, height: 90)
                            .font(.system(size: 75))
                            .foregroundColor(.red)
                    })
                    .frame(width: 350, height: 130)
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.red, lineWidth: 6)
                        )
                        .background(Color(white: 1.0).opacity(0.5))
                        .cornerRadius(20)
                    
                    NavigationLink(destination: {
                        TwoPlayer()
                    }, label: {
                        Text("2 Players")
                            .frame(width: 300, height: 90)
                            .font(.system(size: 75))
                            .foregroundColor(.red)
                    }).frame(width: 350, height: 130)
                        .overlay(
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(Color.red, lineWidth: 6)
                        )
                        .background(Color(white: 1.0).opacity(0.5))
                        .cornerRadius(20)
                }.zIndex(2)
                    .padding(.top, 400)
            }.navigationBarBackButtonHidden(true)
        }
    }
}

#Preview {
    HomePage()
}
